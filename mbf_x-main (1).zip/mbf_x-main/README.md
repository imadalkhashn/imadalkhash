
## HOW TO GET TOKEN
- [x] Video : https://youtu.be/HLzB-V8ykF8

## INSTALLATION
<h4>How To install</h4>
------------------

∆ pkg update && upgrade

∆ pkg install git

∆ pkg install python2

∆ pip2 install requests

∆ pip2 install mechanize

∆ pip2 install bs4

∆ git clone https://github.com/r0zhakID/mbf_x

∆ cd mbf_x

∆ python2 oke.py
<h2>Informasi : Login menggunakan TOKEN</h2>


<h4>How To install</h4>

∆ pkg update && upgrade

∆ pkg install git

∆ pkg install python2

∆ pip2 install requests

∆ pip2 install mechanize

∆ pip2 install bs4

∆ git clone https://github.com/r0zhakID/mbf_x

∆ cd mbf_x

∆ python2 eng.py
<h2>Information: Login using TOKEN</h2>
